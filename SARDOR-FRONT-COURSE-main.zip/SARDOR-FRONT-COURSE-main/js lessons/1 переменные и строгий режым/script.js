let number = 5;
const leftBorderWidth = 1;

number = 10;
console.log(number);

    const obj = {
    a: 50

    };

    obj.a = 10;

    console.log(obj);