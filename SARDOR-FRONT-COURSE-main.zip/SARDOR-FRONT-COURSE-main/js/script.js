// const  hamburger = 5;
// const  fries = 0;


// if (hamburger   && fries){
//     console.log('Я сыт!');
    
// }




const  hamburger = 2;
const  fries = 1;


if (hamburger === 3 && fries){
    console.log('Я сыт!');
    
}